NB: All layers have outline layer - 
#.GML = milling and outline layer 
Files created using itead studio ITeadstudio_CAM6.cam
